# Fast Rabbit — Ride Booking API + App

This package contains the Fast Rabbit customer app and a Node/Express backend starter.

## What is connected
- GPS location from the device/browser
- Customer booking API
- Fare estimation API
- Online captain status/demo matching
- Booking status polling
- Razorpay order + signature verification endpoints (requires your own merchant keys)
- OpenAI customer-support endpoint (requires your own OpenAI API key)

## Important
OpenAI is used for AI support; it does not replace maps, GPS, driver dispatch, or payment infrastructure. Real map routing/ETA and real driver tracking require a maps/location provider and a production backend. Real online payments require a Razorpay merchant account and server-side keys.

## Run API
1. Copy `.env.example` to `.env` and fill your server secrets.
2. Run `npm install`.
3. Run `npm start`.
4. For Android, set the app API URL in local storage as `FAST_RABBIT_API` to the HTTPS URL of your deployed backend.

Never put `OPENAI_API_KEY` or `RAZORPAY_KEY_SECRET` inside the Android/web frontend.
