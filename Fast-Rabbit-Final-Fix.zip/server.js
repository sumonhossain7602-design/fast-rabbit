const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const OpenAI = require('openai');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 8080;
const bookings = new Map();

function money(n){ return Math.round(Number(n) || 0); }
function fareFor(type, km){
  const base = { 'Rabbit Bike': 35, 'Rabbit Auto': 55, 'Rabbit Cab': 90 }[type] || 35;
  const perKm = { 'Rabbit Bike': 10, 'Rabbit Auto': 14, 'Rabbit Cab': 20 }[type] || 10;
  return Math.max(base, Math.round(base + Math.max(0, km - 1) * perKm));
}

app.get('/api/health', (req,res)=>res.json({ok:true,service:'Fast Rabbit API'}));

app.post('/api/fare/estimate', (req,res)=>{
  const {vehicleType='Rabbit Bike', distanceKm=1} = req.body || {};
  res.json({vehicleType, distanceKm:Number(distanceKm), estimatedFare:fareFor(vehicleType, Number(distanceKm))});
});

app.get('/api/drivers/online', (req,res)=>{
  res.json({online: 12, nearby: [
    {id:'captain_demo_1', name:'Rabbit Captain', rating:4.8, etaMinutes:3, vehicle:'Bike'}
  ]});
});

app.post('/api/bookings', (req,res)=>{
  const {pickup, dropoff, vehicleType='Rabbit Bike', distanceKm=1, paymentMethod='cash'} = req.body || {};
  if(!pickup || !dropoff) return res.status(400).json({error:'pickup and dropoff are required'});
  const id = 'FR-' + crypto.randomBytes(5).toString('hex').toUpperCase();
  const booking = {id,pickup,dropoff,vehicleType,distanceKm:Number(distanceKm),fare:fareFor(vehicleType, distanceKm),paymentMethod,status:'searching',createdAt:new Date().toISOString()};
  bookings.set(id, booking);
  setTimeout(()=>{ const b=bookings.get(id); if(b && b.status==='searching'){b.status='captain_assigned';b.captain={id:'captain_demo_1',name:'Rabbit Captain',rating:4.8,etaMinutes:3};}}, 1200);
  res.status(201).json(booking);
});

app.get('/api/bookings/:id', (req,res)=>{
  const b=bookings.get(req.params.id); if(!b) return res.status(404).json({error:'Booking not found'}); res.json(b);
});

app.post('/api/payments/order', async (req,res)=>{
  const {amount, currency='INR', bookingId} = req.body || {};
  if(!amount || !bookingId) return res.status(400).json({error:'amount and bookingId are required'});
  if(!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET){
    return res.status(503).json({error:'Razorpay is not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET on the server.'});
  }
  try{
    const Razorpay = require('razorpay');
    const razorpay = new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET});
    const order = await razorpay.orders.create({amount:money(amount)*100,currency,receipt:bookingId});
    res.json({orderId:order.id,keyId:process.env.RAZORPAY_KEY_ID,amount:order.amount,currency:order.currency});
  }catch(e){res.status(500).json({error:'Payment order creation failed',detail:e.message});}
});

app.post('/api/payments/verify', (req,res)=>{
  const {orderId,paymentId,signature} = req.body || {};
  if(!process.env.RAZORPAY_KEY_SECRET) return res.status(503).json({error:'Payment provider is not configured'});
  const expected = crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET).update(`${orderId}|${paymentId}`).digest('hex');
  if(expected !== signature) return res.status(400).json({verified:false,error:'Invalid payment signature'});
  res.json({verified:true,paymentId});
});

app.post('/api/ai/support', async (req,res)=>{
  const {message} = req.body || {};
  if(!message) return res.status(400).json({error:'message is required'});
  if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:'OpenAI is not configured. Add OPENAI_API_KEY on the server.'});
  try{
    const client = new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-5.6-luna',
      instructions:'You are Fast Rabbit customer support. Give concise, safe, factual help about ride booking, fares, payments, pickup/drop-off, and app navigation. Never claim a real driver, payment, or booking exists unless the API data says so.',
      input: message
    });
    res.json({reply:response.output_text});
  }catch(e){res.status(500).json({error:'AI request failed',detail:e.message});}
});

app.listen(PORT, ()=>console.log(`Fast Rabbit API listening on :${PORT}`));
